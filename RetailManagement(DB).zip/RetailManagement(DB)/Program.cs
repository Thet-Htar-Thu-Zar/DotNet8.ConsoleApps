﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using RetailManagement_DB_;

RetailManagementSystem retail = new RetailManagementSystem();
//retail.CreateProduct();
//retail.ShowProduct();
//retail.ShowProducts();
//retail.UpdateProduct();
//retail.DeleteProduct();
//retail.CreateSaleReport();

retail.RetailSystem();


